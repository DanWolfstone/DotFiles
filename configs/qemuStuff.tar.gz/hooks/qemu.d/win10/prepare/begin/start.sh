#!/bin/bash

#Stop Display manager
systemctl stop sddm.service

# Unbind EFI-Framebuffer so I can keep it when on login screen
echo efi-framebuffer.0 > /sys/bus/platform/drivers/efi-framebuffer/unbind

sleep 2
