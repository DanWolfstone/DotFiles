#!/bin/bash

# Rebind Framebuffer
echo "efi-framebuffer.0" > /sys/bus/platform/drivers/efi-framebuffer/bind

# restart display manager service
systemctl start sddm.service
